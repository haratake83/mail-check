# メール判定.com

メール本文と送信元アドレスから、詐欺・フィッシングの疑いがあるポイントを指摘する静的サイトです。
判定はすべてブラウザ内のJavaScriptで行い、サーバーへの送信はありません。

## ファイル構成
- `index.html` … サイト本体（HTML/CSS/JSすべてこの1ファイル）
- `vercel.json` … Vercel用設定（セキュリティヘッダー）
- `robots.txt`

## Vercelへのデプロイ
### 方法1: CLI
```
npm i -g vercel
cd mail-hantei
vercel          # プレビュー
vercel --prod   # 本番
```
Framework Preset は「Other」、ビルドコマンドと出力ディレクトリは空欄のままでOKです。

### 方法2: GitHub連携
このフォルダをGitHubリポジトリにpushし、Vercelの「Add New → Project」からインポートします。

## 独自ドメイン「メール判定.com」
日本語ドメインは内部的にPunycode `xn--` 形式で扱われます。ドメイン取得後、Vercelのプロジェクト設定の Domains に追加し、表示されるDNSレコードをレジストラ側で設定してください。

## 免責
判定結果は参考情報です。最終的な判断は利用者ご自身で行ってください。
